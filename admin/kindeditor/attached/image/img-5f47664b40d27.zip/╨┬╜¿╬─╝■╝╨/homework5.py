a=[]
d=[]
nn=i=j=s=0

def PBML(a):  #帮助排序的函数
    return a[4]
def countBML(we,he): #定义函数计算BML
    BML = round(we / (he ** 2), 2)
    return  BML
def fxBML(BML):      #函数得出分析结果
    if BML < 18.5:
        fx = "偏瘦"
    elif BML < 24:
        fx = "正常"
    elif BML < 28:
        fx = "偏胖"
    else:
        fx = "肥胖"
    return  fx
# def txt_write(filename,data):
#     file=open(filename,"a")
#     for i in range(len(data)):
#         rdata= str(data[i]).replace('[', '').replace(']', '')  # 去除[],这两行按数据不同，可以选择
#         rdata= rdata.replace("'", '').replace(',', '') + '\n'  # 去除单引号，逗号，每行末尾追加换行符
#         file.write(rdata)
#     file.close()
#     print("保存文件成功")
while True:
 try:
  nn=int(input("请输入学生人数："))
  break
 except ValueError:
  print("您输入的数据类型有误，请重新输入！")

while i<nn:
  we=he=0
  while True:
    try:
      Form = input("请输学生信息：")
      k = Form.split()
      n=(k[0])
      s = float(k[1])
      t = float(k[2])
      y = int(k[3])
      if 0.2<s<2.5 and 20<t<300 and 50 < y < 200:
          a.append(n),  a.append(s), a.append(t),  a.append(y)
          we=we+t
          he=he+s
          BML=countBML(we, he)
          fx = fxBML(BML)
          a.append(BML)
          a.append(fx)
          break
      else:
          print("信息不符合要求，请重新输入")
          #抛出程序异常,并要求用户重新输入
    except ValueError:
         print("您输入的数据类型有误，请重新输入！")
  d.append(a[0:])
  i=i+1
  # 释放列表a
  a.clear()
  d.sort(key=PBML, reverse=True)  # 对列表的BML进行排序
  file=open(file="b.txt", mode='w+')
  for l in d:
      s = str(l).replace("[", "").replace("]", "").replace(",", "   ").replace("'", "")+ "\n"
      file.write(s)
  file.close()
print("文件保存成功！")
with open('b.txt', 'r') as file:       #读文件的简化方法
    line = file.read().strip()        #加strip可以保证不空行
    linestr = line.split("\n")         # 以换行符分隔
print("姓名    身高    体重    腰围   BML指数  分析结果")
for i in range(len(linestr)):
    print(linestr[i])










